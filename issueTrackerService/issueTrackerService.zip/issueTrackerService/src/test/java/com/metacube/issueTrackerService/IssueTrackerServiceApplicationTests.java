package com.metacube.issueTrackerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueTrackerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
